Single-screen preconfigured spinner.
Edit PRESET_SEQUENCE in index.html before publishing.
Example: ["A","D","B","F","C","A"].
The audience screen shows only the wheel, SPIN and result.
The settings panel is hidden until the small gear is tapped.
For maximum concealment, remove the #settings button and #panel from index.html before publishing.
